
<?php $__env->startSection('contenido'); ?>
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="\npm\bootstrap-table@1.18.3\dist\bootstrap-table.min.css">
<?php $__env->stopSection(); ?>
<div class="page-content container container-plus">
    <div class="page-header">
        <h1 class="page-title text-primary-d2">
            Nueva venta
            <!--<small class="page-info text-secondary-d2">
                <i class="fa fa-angle-double-right text-80"></i>
                extended tables plugin
            </small>-->
        </h1>
    </div>
</div>
<div role="main" class="main-content">

          <div class="page-content container container-plus">
            <div class="container px-0">

              <div class="row mt-0">
                <div class="col-12 col-lg-10 offset-lg-1 col-xl-8 offset-xl-2">

                  <div class="page-header border-0 mb-0">
                    <h1 class="page-title text-dark-l3 text-115">
                      Venta
                      <i class="fa fa-angle-right text-80 ml-1"></i>
                      <small class="page-info text-dark-m3">
                        #111-222
                      </small>
                    </h1>

                    <div class="page-tools">
                      <div class="action-buttons">
                        <a class="btn bg-white btn-light mx-1px text-95 shadow-sm" href="#" data-title="Print">
                          <i class="mr-1 fa fa-print text-primary text-120 w-2"></i>
                          Imprimir
                        </a>
                        <a class="btn bg-white btn-light mx-1px text-95 shadow-sm" href="#" data-title="PDF">
                          <i class="mr-1 far fa-file-pdf text-danger text-120 w-2"></i>
                          Exportar
                        </a>
                      </div>
                    </div>
                  </div>


                  <div class="card dcard mb-4">
                    <div class="card-body px-4 px-lg-5">

                      <div class="text-center">
                        <i class="fa fa-leaf text-200 text-green-m1 mr-1 ml-n4"></i>
                        <span class="text-dark-m3 text-140">
                        Llantimax
                    </span>
                        <br>
                        <span class="text-dark-l2 text-90">
                        Sucursal San Miguel
                    </span>
                      </div>

                      <div class="row mt-4">
                        <div class="col-sm-6">
                          <div>
                            <div class="text-100 text-grey-m1 align-middle">
                                <div class="mt-1 mb-2 text-secondary-d1 text-600 text-125">
                              Cliente
                            </div>
                            </div>

                            <div class="text-600 text-100 text-primary mt-2">
                              Juan Jesús Padrón Díaz
                            </div>

                            <div class="text-dark-l1">
                              <div class="my-1">
                                Teléfono:
                              </div>
                              <div class="my-1">
                                Correo:
                              </div>
                            </div>
                          </div>
                        </div><!-- /.col -->


                        <div class="col-sm-6 align-self-start d-sm-flex justify-content-end text-95">
                          <hr class="d-sm-none">
                          <div class="text-dark-l1">
                            <div class="mt-1 mb-2 text-secondary-d1 text-600 text-125">
                              Ticket
                            </div>

                            <div class="my-2">
                              <i class="fa fa-circle text-blue-m2 text-xs mr-1"></i>
                              <span class="text-600 text-90">
                                    ID:
                                </span>
                              #111-222
                            </div>

                            <div class="my-2">
                              <i class="fa fa-circle text-blue-m2 text-xs mr-1"></i>
                              <span class="text-600 text-90">
                                    Fecha:
                                </span>
                              Oct 12, 2019
                            </div>
                          </div>
                        </div><!-- /.col -->
                      </div><!-- /.قخص -->
                      <div class="mt-4">
                        <div class="row text-600 text-95 text-secondary-d3 brc-green-l1 py-25 border-y-2">
                          <div class="d-none d-sm-block col-1">
                            #
                          </div>

                          <div class="col-7 col-sm-5">
                            Descripción
                          </div>

                          <div class="d-none d-sm-block col-4 col-sm-2">
                            Cant.
                          </div>

                          <div class="d-none d-sm-block col-sm-2">
                            Precio unidad
                          </div>

                          <div class="col-5 col-sm-2">
                            Monto
                          </div>
                        </div>

                        <div class="text-95 text-dark-m3">
                          <div class="row mb-2 mb-sm-0 py-25">
                            <div class="d-none d-sm-block col-1">
                              1
                            </div>

                            <div class="col-7 col-sm-5">
                              Domain registration
                            </div>

                            <div class="d-none d-sm-block col-2">
                              2
                            </div>

                            <div class="d-none d-sm-block col-2 text-95">
                              $10
                            </div>

                            <div class="col-5 col-sm-2 text-secondary-d3 text-600">
                              $20
                            </div>
                          </div>

                          <div class="row mb-2 mb-sm-0 py-25 bgc-green-l4">
                            <div class="d-none d-sm-block col-1">
                              2
                            </div>

                            <div class="col-7 col-sm-5">
                              Web hosting
                            </div>

                            <div class="d-none d-sm-block col-2">
                              1
                            </div>

                            <div class="d-none d-sm-block col-2 text-95">
                              $30
                            </div>

                            <div class="col-5 col-sm-2 text-secondary-d3 text-600">
                              $30
                            </div>
                          </div>

                          <div class="row mb-2 mb-sm-0 py-25">
                            <div class="d-none d-sm-block col-1">
                              3
                            </div>

                            <div class="col-7 col-sm-5">
                              Software development
                            </div>

                            <div class="d-none d-sm-block col-2">
                              --
                            </div>

                            <div class="d-none d-sm-block col-2 text-95">
                              $1,700
                            </div>

                            <div class="col-5 col-sm-2 text-secondary-d3 text-600">
                              $1,700
                            </div>
                          </div>

                          <div class="row mb-2 mb-sm-0 py-25 bgc-green-l4">
                            <div class="d-none d-sm-block col-1">
                              4
                            </div>

                            <div class="col-7 col-sm-5">
                              Consulting
                            </div>

                            <div class="d-none d-sm-block col-2">
                              1 Year
                            </div>

                            <div class="d-none d-sm-block col-2 text-95">
                              $500
                            </div>

                            <div class="col-5 col-sm-2 text-secondary-d3 text-600">
                              $500
                            </div>
                          </div>
                        </div>

                        <div class="row border-b-2 brc-green-l1"></div>

                        <!-- or use a table instead -->
                        <!--
                    <div class="table-responsive">
                        <table class="table table-striped table-borderless border-0 border-b-2 brc-default-l1">
                            <thead class="bg-none bgc-default-tp1">
                                <tr class="text-white">
                                    <th class="opacity-2">#</th>
                                    <th>Description</th>
                                    <th>Qty</th>
                                    <th>Unit Price</th>
                                    <th width="140">Amount</th>
                                </tr>
                            </thead>

                            <tbody class="text-95 text-secondary-d3">
                                <tr></tr>
                                <tr>
                                    <td>1</td>
                                    <td>Domain registration</td>
                                    <td>2</td>
                                    <td class="text-95">$10</td>
                                    <td class="text-secondary-d2">$20</td>
                                </tr> 
                            </tbody>
                        </table>
                    </div>
                    -->


                        <div class="row mt-4">
                          <div class="col-12 col-sm-7 mt-2 mt-lg-0">
                            <div class="d-inline-block text-center">
                              <p class="text-95 text-dark-m2">
                                <i class="fa fa-exclamation-triangle text-danger-m2 mr-1"></i>
                                Selecciona un método de pago
                                <br>
                                para finalizar la compra
                              </p>

                              <div>
                                <form autocomplete="off" class="p-2 p-sm-3 bgc-secondary-l4 radius-1 btn-group btn-group-toggle mx-n3 mx-sm-0" data-toggle="buttons">
                                  <div role="button" class="mr-1 p-3 border-2 btn btn-brc-tp shadow-sm btn-light btn-text-blue btn-h-lighter-blue btn-a-light-blue bgc-white">
                                    <input type="radio" name="place" id="place1" value="1">
                                    <i class="fab fa-paypal d-block text-150 text-blue-d1 w-4 mx-2"></i>
                                  </div>

                                  <div role="button" class="mr-1 p-3 border-2 btn btn-brc-tp shadow-sm btn-text-purple btn-light btn-h-lighter-purple btn-a-light-purple bgc-white">
                                    <input type="radio" name="place" id="place2" value="1">
                                    <i class="far fa-credit-card d-block text-150 text-purple-d1 w-4 mx-2"></i>
                                  </div>

                                  <div role="button" class="p-3 border-2 btn btn-brc-tp shadow-sm btn-light btn-text-orange btn-h-lighter-orange btn-a-light-orange bgc-white">
                                    <input type="radio" name="place" id="place3" value="3">
                                    <i class="fab fa-bitcoin d-block text-150 text-orange-d3 w-4 mx-2"></i>
                                  </div>
                                </form>
                              </div>
                            </div>
                          </div>
                          <div class="col-12 col-sm-5 text-dark-l1 text-90 order-first order-sm-last">
                               <div class="row my-2 align-items-center bgc-green-d3 p-2 radius-1">
                              <div class="col-7 text-right text-white text-110">
                                Monto Total
                              </div>
                              <div class="col-5">
                                <span class="text-150 text-white">
                                        $2,475
                                    </span>
                              </div>
                            </div>
                            <div class="row my-1">
                                <div class="col-8">
                                    <button type="button" class="btn btn-app btn-blue btn-xs my-1">
                                        <i class="d-block h-4 fa fa-shopping-cart text-150"></i>
                                            <div class="col-12" mr-3 mr-lg-1>
                                                Finalizar compra 
                                            </div>
                                    </button>
                              </div>
                            </div>
                          </div>
                        </div>

                        <hr class="brc-secondary-l3 border-t-2">

                        <div class="text-center text-secondary-d3 text-105">
                          Gracias por su compra!
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\San_miguel\llantero\resources\views/ticket.blade.php ENDPATH**/ ?>