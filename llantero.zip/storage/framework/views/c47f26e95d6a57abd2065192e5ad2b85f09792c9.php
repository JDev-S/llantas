<?php echo e($message); ?>

<br/>
<br/>
<?php echo e($message2); ?>

<br/>
<br/>
<?php echo e($message3); ?>

<br/>
<br/>
<?php echo e($message4); ?>

<br/>
<br/>
<?php echo e($message5); ?><?php /**PATH E:\laravel\San_miguel\llantero\resources\views/email_template.blade.php ENDPATH**/ ?>