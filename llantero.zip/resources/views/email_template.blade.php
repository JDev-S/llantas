{{ $message }}
<br/>
<br/>
{{$message2}}
<br/>
<br/>
{{$message3}}
<br/>
<br/>
{{$message4}}
<br/>
<br/>
{{$message5}}